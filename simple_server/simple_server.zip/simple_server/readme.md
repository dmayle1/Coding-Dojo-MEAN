# To set up project, install all of your dependencies #
```
  npm install && bower install
```

Bower init
Bower install angular --save
Bower install angular-route --save
npm init -y
npm install express
npm install mongoose
npm install body-parser